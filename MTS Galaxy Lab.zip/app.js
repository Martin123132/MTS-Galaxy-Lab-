(function () {
  "use strict";

  var CONST = {
    gamma0: 809.956,
    rMax: 1.758948,
    mlDisk: 0.5,
    mlBulge: 0.7,
    qDefault: 0.77
  };

  var FRAMEWORK_PRESETS = {
    mts: "gamma0 * leff * (1 - exp(-pow(r / leff, q)))",
    baryon: "0",
    soft: "gamma0 * leff * (1 - exp(-r / leff))",
    outer: "gamma0 * leff * pow(max(0, x), 0.75) * (1 - exp(-memory / 2))",
    residual: "max(0, pow(vObs, 2) - pow(vBar, 2))"
  };

  var ETG_LOCKED = {
    NGC2685: { h: 2.235, r90: 9.030, sigma80: 0.1341, logy: 5.0086 },
    NGC2824: { h: 1.577, r90: 7.260, sigma80: 19.464, logy: 7.7130 },
    NGC2859: { h: 1.666, r90: 5.940, sigma80: 2.599, logy: 7.2560 },
    NGC2974: { h: 3.427, r90: 13.066, sigma80: 28.073, logy: 7.3670 },
    NGC3522: { h: 2.503, r90: 9.682, sigma80: 1.413, logy: 4.7000 },
    NGC3626: { h: 2.239, r90: 9.168, sigma80: 10.923, logy: 7.2810 },
    NGC3838: { h: 1.744, r90: 4.791, sigma80: 0.4185, logy: 5.3280 },
    NGC3941: { h: 1.312, r90: 4.927, sigma80: 2.447, logy: 7.0810 },
    NGC3945: { h: 2.867, r90: 13.775, sigma80: 30.944, logy: 7.5340 },
    NGC3998: { h: 1.461, r90: 5.625, sigma80: 0.710, logy: 6.6550 },
    NGC4203: { h: 1.899, r90: 7.148, sigma80: 2.740, logy: 6.8390 },
    NGC4262: { h: 1.249, r90: 4.430, sigma80: 1.802, logy: 6.4840 },
    NGC4278: { h: 2.553, r90: 9.555, sigma80: 18.007, logy: 7.2870 },
    NGC5582: { h: 3.876, r90: 16.576, sigma80: 0.4987, logy: 5.1790 },
    NGC6798: { h: 3.317, r90: 13.121, sigma80: 0.5183, logy: 5.5970 },
    UGC6176: { h: 1.400, r90: 5.945, sigma80: 2.408, logy: 6.6920 }
  };

  var state = {
    mode: "synthetic",
    seed: 7,
    curve: null,
    observed: null,
    route: null,
    ltgIndex: [],
    ltgBrowser: {
      search: "",
      route: "all",
      sort: "rmse-desc",
      hunt: "all"
    },
    framework: {
      expression: FRAMEWORK_PRESETS.mts,
      compiled: null,
      error: null,
      current: null,
      batch: [],
      batchSummary: null
    },
    particles: [],
    lastFrame: 0,
    canvasScale: 1
  };

  var controls = {};
  var canvas = document.getElementById("galaxyCanvas");
  var ctx = canvas.getContext("2d", { alpha: false });
  var FRAMEWORK_VARS = [
    "r",
    "x",
    "h",
    "rOut",
    "fGas",
    "fGasOut",
    "leff",
    "memory",
    "q",
    "gamma0",
    "rMax",
    "mlDisk",
    "mlBulge",
    "vGas",
    "vDisk",
    "vBulge",
    "vBar",
    "vObs",
    "uObs",
    "pi",
    "e"
  ];
  var FRAMEWORK_FUNCS = {
    abs: Math.abs,
    sqrt: Math.sqrt,
    pow: Math.pow,
    exp: Math.exp,
    log: Math.log,
    log10: Math.log10 || function (v) { return Math.log(v) / Math.LN10; },
    min: Math.min,
    max: Math.max,
    sin: Math.sin,
    cos: Math.cos,
    tan: Math.tan,
    tanh: Math.tanh || function (v) {
      var ev = Math.exp(2 * v);
      return (ev - 1) / (ev + 1);
    },
    atan: Math.atan,
    atan2: Math.atan2,
    floor: Math.floor,
    ceil: Math.ceil,
    round: Math.round
  };

  function $(id) {
    return document.getElementById(id);
  }

  function cacheControls() {
    [
      "h",
      "rOut",
      "diskAmp",
      "gasAmp",
      "bulgeAmp",
      "fGas",
      "q",
      "speed",
      "showMtsOnly"
    ].forEach(function (id) {
      controls[id] = $(id);
    });
  }

  function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
  }

  function fmt(value, digits) {
    if (!Number.isFinite(value)) return "--";
    return Number(value).toFixed(digits);
  }

  function seededRandom() {
    state.seed = (state.seed * 1664525 + 1013904223) >>> 0;
    return state.seed / 4294967296;
  }

  function readParams() {
    return {
      h: Number(controls.h.value),
      rOut: Number(controls.rOut.value),
      diskAmp: Number(controls.diskAmp.value),
      gasAmp: Number(controls.gasAmp.value),
      bulgeAmp: Number(controls.bulgeAmp.value),
      fGas: Number(controls.fGas.value),
      q: Number(controls.q.value),
      speed: Number(controls.speed.value),
      showMtsOnly: controls.showMtsOnly.checked
    };
  }

  function updateOutputs(p) {
    $("hOut").textContent = fmt(p.h, 1);
    $("rOutOut").textContent = fmt(p.rOut, 0);
    $("diskAmpOut").textContent = fmt(p.diskAmp, 0);
    $("gasAmpOut").textContent = fmt(p.gasAmp, 0);
    $("bulgeAmpOut").textContent = fmt(p.bulgeAmp, 0);
    $("fGasOut").textContent = fmt(p.fGas, 2);
    $("qOut").textContent = fmt(p.q, 2);
    $("speedOut").textContent = fmt(p.speed, 1);
  }

  function leffExact(h, rOut, fGasOut) {
    var sMem = (0.9 / Math.PI) * (rOut / h);
    var memoryLoad = (1 - fGasOut) * (rOut / h);
    return 1.8 * h * (1 + sMem * (1 - Math.exp(-memoryLoad / sMem)));
  }

  function leffSat(h, rOut) {
    var sMem = (0.9 / Math.PI) * (rOut / h);
    return 1.8 * h * (1 + sMem);
  }

  function lGap(h, rOut, fGasOut) {
    return leffSat(h, rOut) - leffExact(h, rOut, fGasOut);
  }

  function memoryLoad(h, rOut, fGasOut) {
    return (1 - fGasOut) * (rOut / h);
  }

  function componentVelocities(r, p) {
    var x = Math.max(0.0001, r / p.h);
    var disk = p.diskAmp * (1 - Math.exp(-x / 1.35)) / Math.sqrt(1 + x / 6.2);
    var gas = p.gasAmp * (1 - Math.exp(-x / 3.2)) * (1 + 0.07 * Math.sin(1.8 * x));
    var rb = Math.max(0.18, 0.33 * p.h);
    var bulge = p.bulgeAmp * Math.sqrt(r / (r + rb)) * Math.exp(-r / Math.max(5.5 * rb, 1));
    return {
      vDisk: Math.max(0, disk),
      vGas: Math.max(0, gas),
      vBulge: Math.max(0, bulge)
    };
  }

  function buildSyntheticCurve() {
    var p = readParams();
    updateOutputs(p);

    var leff = leffExact(p.h, p.rOut, p.fGas);
    var mem = memoryLoad(p.h, p.rOut, p.fGas);
    var points = [];
    var count = 260;

    for (var i = 0; i < count; i += 1) {
      var t = i / (count - 1);
      var r = 0.08 + Math.pow(t, 1.25) * (p.rOut - 0.08);
      var c = componentVelocities(r, p);
      var bar2 = c.vGas * c.vGas + CONST.mlDisk * c.vDisk * c.vDisk + CONST.mlBulge * c.vBulge * c.vBulge;
      var mts2 = CONST.gamma0 * leff * (1 - Math.exp(-Math.pow(r / leff, p.q)));
      var total2 = bar2 + mts2;
      var u = (total2 - CONST.mlDisk * c.vDisk * c.vDisk - CONST.mlBulge * c.vBulge * c.vBulge) /
        (CONST.gamma0 * r * CONST.rMax);

      points.push({
        r: r,
        vDisk: c.vDisk,
        vGas: c.vGas,
        vBulge: c.vBulge,
        vBar: Math.sqrt(Math.max(0, bar2)),
        vMts: Math.sqrt(Math.max(0, mts2)),
        vTotal: Math.sqrt(Math.max(0, total2)),
        u: u
      });
    }

    state.curve = {
      kind: "synthetic",
      name: "Synthetic transport disk",
      h: p.h,
      rOut: p.rOut,
      fGasOut: p.fGas,
      q: p.q,
      leff: leff,
      memoryLoad: mem,
      rmse: null,
      points: points
    };
    state.observed = null;
    state.route = classifyRoute(points, state.curve);
    scoreCurrentFramework();
    updateDiagnostics();
    drawPlots();
  }

  function parseRotmod(text, name) {
    var rows = [];
    text.split(/\r?\n/).forEach(function (line) {
      var trimmed = line.trim();
      if (!trimmed || trimmed[0] === "#" || trimmed[0] === "!") return;
      var parts = trimmed.split(/\s+/).map(Number);
      if (parts.length >= 6 && parts.every(function (v, idx) { return idx > 7 || Number.isFinite(v); })) {
        rows.push({
          r: parts[0],
          vObs: parts[1],
          err: parts[2],
          vGas: parts[3],
          vDisk: parts[4],
          vBulge: parts[5],
          sbDisk: Number.isFinite(parts[6]) ? parts[6] : 0,
          sbBulge: Number.isFinite(parts[7]) ? parts[7] : 0
        });
      }
    });

    if (rows.length < 2) {
      throw new Error("ROTMOD text did not contain enough numeric rows.");
    }

    var galaxyName = name || "Imported ROTMOD";
    var h = fitScaleLength(rows);
    var rOut = rows[rows.length - 1].r;
    var last = rows[rows.length - 1];
    var vbarOut2 = last.vGas * last.vGas + CONST.mlDisk * last.vDisk * last.vDisk + CONST.mlBulge * last.vBulge * last.vBulge;
    var fGasOut = vbarOut2 > 0 ? clamp((last.vGas * last.vGas) / vbarOut2, 0, 1) : 0;
    var leff = leffExact(h, rOut, fGasOut);
    var mem = memoryLoad(h, rOut, fGasOut);
    var sse = 0;
    var points = rows.map(function (row) {
      var bar2 = row.vGas * row.vGas + CONST.mlDisk * row.vDisk * row.vDisk + CONST.mlBulge * row.vBulge * row.vBulge;
      var mts2 = CONST.gamma0 * leff * (1 - Math.exp(-Math.pow(row.r / leff, CONST.qDefault)));
      var model = Math.sqrt(Math.max(0, bar2 + mts2));
      var u = (row.vObs * row.vObs - CONST.mlDisk * row.vDisk * row.vDisk - CONST.mlBulge * row.vBulge * row.vBulge) /
        (CONST.gamma0 * row.r * CONST.rMax);
      var residual = model - row.vObs;
      sse += residual * residual;

      return {
        r: row.r,
        vDisk: row.vDisk,
        vGas: row.vGas,
        vBulge: row.vBulge,
        vBar: Math.sqrt(Math.max(0, bar2)),
        vMts: Math.sqrt(Math.max(0, mts2)),
        vTotal: model,
        vObs: row.vObs,
        u: u
      };
    });

    return {
      kind: "observed",
      name: cleanGalaxyName(galaxyName),
      h: h,
      rOut: rOut,
      fGasOut: fGasOut,
      q: CONST.qDefault,
      leff: leff,
      memoryLoad: mem,
      rmse: Math.sqrt(sse / rows.length),
      points: points,
      raw: text
    };
  }

  function cleanGalaxyName(name) {
    return String(name || "Imported ROTMOD")
      .replace(/^.*[\\/]/, "")
      .replace(/_rotmod\.dat$/i, "");
  }

  function analyzeLtgSample(sample, index) {
    try {
      var curve = parseRotmod(sample.text, sample.name);
      var route = classifyRoute(curve.points, curve);
      return {
        index: index,
        name: curve.name,
        route: route.id,
        rmse: curve.rmse,
        h: curve.h,
        rOut: curve.rOut,
        fGasOut: curve.fGasOut,
        leff: curve.leff,
        memoryLoad: curve.memoryLoad,
        hOverRout: route.hOverRout,
        u0: route.u0,
        uOut: route.uOut,
        uMax: route.uMax,
        xCross: route.xCrossNorm,
        u075: route.u075,
        lGap: route.lGap,
        gScalar: route.gScalar,
        hGuard: route.hGuard,
        priorityL: route.priorityL,
        lateLoad: route.lateLoad,
        ltgCurvatureA: route.ltgCurvatureA,
        cdc: route.cdc,
        outerViable: route.outerViable
      };
    } catch (error) {
      return {
        index: index,
        name: cleanGalaxyName(sample.name),
        route: "parse-error",
        rmse: NaN,
        error: error.message
      };
    }
  }

  function fitScaleLength(rows) {
    var xs = [];
    var ys = [];
    rows.forEach(function (row) {
      if (row.sbDisk > 0 && row.r > 0) {
        xs.push(row.r);
        ys.push(Math.log(row.sbDisk));
      }
    });

    if (xs.length < 3) {
      return Math.max(0.8, rows[rows.length - 1].r / 3.9);
    }

    var n = xs.length;
    var sx = 0;
    var sy = 0;
    var sxx = 0;
    var sxy = 0;
    for (var i = 0; i < n; i += 1) {
      sx += xs[i];
      sy += ys[i];
      sxx += xs[i] * xs[i];
      sxy += xs[i] * ys[i];
    }

    var denom = n * sxx - sx * sx;
    if (Math.abs(denom) < 1e-9) return Math.max(0.8, rows[rows.length - 1].r / 3.9);
    var slope = (n * sxy - sx * sy) / denom;
    if (slope >= 0) return Math.max(0.8, rows[rows.length - 1].r / 3.9);
    return clamp(-1 / slope, 0.25, rows[rows.length - 1].r * 2);
  }

  function parseComponentTable(text) {
    var rows = [];
    text.split(/\r?\n/).forEach(function (line) {
      var trimmed = line.trim();
      if (!trimmed || trimmed[0] === "!" || trimmed[0] === "#") return;
      var parts = trimmed.split(/\s+/).map(Number);
      if (parts.length >= 3 && Number.isFinite(parts[0]) && Number.isFinite(parts[1]) && Number.isFinite(parts[2])) {
        rows.push({ r: parts[0], sigma: parts[1], v: parts[2] });
      }
    });
    return rows;
  }

  function interpRows(rows, r, key) {
    if (!rows.length) return 0;
    if (r <= rows[0].r) return rows[0][key];
    if (r >= rows[rows.length - 1].r) return rows[rows.length - 1][key];
    for (var i = 1; i < rows.length; i += 1) {
      if (rows[i].r >= r) {
        var a = rows[i - 1];
        var b = rows[i];
        var t = (r - a.r) / (b.r - a.r);
        return a[key] * (1 - t) + b[key] * t;
      }
    }
    return rows[rows.length - 1][key];
  }

  function fitComponentScaleLength(rows) {
    var xs = [];
    var ys = [];
    rows.forEach(function (row) {
      if (row.sigma > 0 && row.r > 0) {
        xs.push(row.r);
        ys.push(Math.log(row.sigma));
      }
    });
    if (xs.length < 3) return null;

    var n = xs.length;
    var sx = 0;
    var sy = 0;
    var sxx = 0;
    var sxy = 0;
    for (var i = 0; i < n; i += 1) {
      sx += xs[i];
      sy += ys[i];
      sxx += xs[i] * xs[i];
      sxy += xs[i] * ys[i];
    }
    var denom = n * sxx - sx * sx;
    if (Math.abs(denom) < 1e-9) return null;
    var slope = (n * sxy - sx * sy) / denom;
    return slope < 0 ? -1 / slope : null;
  }

  function enclosedRadius(rows, frac) {
    var mass = [];
    var cumul = [];
    var total = 0;
    for (var i = 0; i < rows.length; i += 1) {
      var dr;
      if (i === 0) {
        dr = rows[1].r - rows[0].r;
      } else if (i === rows.length - 1) {
        dr = rows[i].r - rows[i - 1].r;
      } else {
        dr = (rows[i + 1].r - rows[i - 1].r) / 2;
      }
      mass[i] = Math.max(0, rows[i].sigma) * rows[i].r * dr;
      total += mass[i];
      cumul[i] = total;
    }

    var target = total * frac;
    for (var j = 0; j < cumul.length; j += 1) {
      if (cumul[j] >= target) {
        return rows[j].r;
      }
    }
    return rows[rows.length - 1].r;
  }

  function sigmaMeanWindow(rows, rOut, fracLo) {
    var total = 0;
    var n = 1000;
    for (var i = 0; i < n; i += 1) {
      var t = i / (n - 1);
      var r = fracLo * rOut * (1 - t) + rOut * t;
      total += interpRows(rows, r, "sigma");
    }
    return total / n;
  }

  function parseEtgSample(sample) {
    var rot = parseRotmod(sample.rotmod, sample.name + "_rotmod.dat");
    var disk = parseComponentTable(sample.disk);
    var bulge = parseComponentTable(sample.bulge);
    var locked = ETG_LOCKED[sample.name] || {};
    var h = locked.h || fitComponentScaleLength(disk) || rot.h;
    var rOut = rot.rOut;
    var count = 220;
    var points = [];
    var vdiskOut = interpRows(disk, rOut, "v");
    var sigma80 = locked.sigma80 || sigmaMeanWindow(disk, rOut, 0.8);
    var r80 = enclosedRadius(disk, 0.8);
    var r90 = locked.r90 || enclosedRadius(disk, 0.9);
    var logy = locked.logy || Math.log((vdiskOut * vdiskOut) / rOut);
    var stageR80 = 4.313 + 0.808 * Math.log(sigma80) + 1.732 * Math.log(rOut / r80);
    var stageR90 = 4.7556 + 0.8348 * Math.log(sigma80) + 1.7153 * Math.log(rOut / r90);

    for (var i = 0; i < count; i += 1) {
      var t = i / (count - 1);
      var r = Math.max(rot.points[0].r, Math.pow(t, 1.1) * rOut);
      var vObs = interpRows(rot.points.map(function (p) { return { r: p.r, v: p.vObs }; }), r, "v");
      var vDisk = interpRows(disk, r, "v");
      var vBulge = interpRows(bulge, r, "v");
      var bar2 = CONST.mlDisk * vDisk * vDisk + CONST.mlBulge * vBulge * vBulge;
      var support2 = Math.max(0, vObs * vObs - bar2);
      var u = (vObs * vObs - CONST.mlDisk * vDisk * vDisk - CONST.mlBulge * vBulge * vBulge) /
        (CONST.gamma0 * r * CONST.rMax);
      points.push({
        r: r,
        vDisk: vDisk,
        vGas: 0,
        vBulge: vBulge,
        vBar: Math.sqrt(Math.max(0, bar2)),
        vMts: Math.sqrt(support2),
        vTotal: vObs,
        vObs: vObs,
        u: u
      });
    }

    rot.points.forEach(function (p) {
      p.sourcePoint = true;
    });

    return {
      kind: "etg",
      name: sample.name,
      h: h,
      rOut: rOut,
      fGasOut: 0,
      q: CONST.qDefault,
      leff: null,
      memoryLoad: null,
      rmse: null,
      points: points,
      observedPoints: rot.points,
      stage4: {
        r80: r80,
        r90: r90,
        sigma80: sigma80,
        logy: logy,
        stageR80: stageR80,
        stageR90: stageR90,
        residualR80: logy - stageR80,
        residualR90: logy - stageR90,
        vdiskOut: vdiskOut
      },
      raw: sample.rotmod
    };
  }

  function valueAtRadius(points, r, key) {
    if (!points.length) return NaN;
    if (r <= points[0].r) return points[0][key];
    if (r >= points[points.length - 1].r) return points[points.length - 1][key];
    for (var i = 1; i < points.length; i += 1) {
      if (points[i].r >= r) {
        var a = points[i - 1];
        var b = points[i];
        var t = (r - a.r) / (b.r - a.r);
        return a[key] * (1 - t) + b[key] * t;
      }
    }
    return points[points.length - 1][key];
  }

  function classifyRoute(points, curve) {
    var u0 = points[0].u;
    var uOut = points[points.length - 1].u;
    var uMax = -Infinity;
    var down = 0;
    var up = 0;
    var xCross = null;

    for (var i = 0; i < points.length; i += 1) {
      uMax = Math.max(uMax, points[i].u);
      if (i > 0) {
        var prev = points[i - 1].u;
        var curr = points[i].u;
        if (prev > 1 && curr <= 1) {
          down += 1;
          var span = prev - curr;
          var t = span !== 0 ? (prev - 1) / span : 0;
          xCross = points[i - 1].r * (1 - t) + points[i].r * t;
        }
        if (prev < 1 && curr >= 1) up += 1;
      }
    }

    var id = "low-load";
    if (u0 < 0 && uOut < 1 && uMax < 1) {
      id = "CDC-low-load";
    } else if (uOut >= 1) {
      id = "outer-infeasible";
    } else if (up > 0) {
      id = "buffered upward-crossing";
    } else if (down > 0) {
      id = "buffered single-crossing";
    }

    var rOut = curve ? curve.rOut : points[points.length - 1].r;
    var h = curve ? curve.h : null;
    var xCrossNorm = xCross == null ? null : xCross / rOut;
    var u075 = valueAtRadius(points, 0.75 * rOut, "u");
    var hOverRout = h ? h / rOut : null;
    var hGuard = h != null ? h >= points[0].r : false;
    var gap = curve && curve.kind !== "etg" ? lGap(curve.h, curve.rOut, curve.fGasOut) : null;
    var mem = curve && curve.memoryLoad != null ? curve.memoryLoad : null;
    var gScalar = mem != null && xCrossNorm != null ? mem * xCrossNorm : null;
    var priorityL = gScalar != null && gap != null ? -10.4 + 8.6 * gScalar + 10.5 * gap : null;
    var lateLoad = hOverRout != null ? (id === "buffered single-crossing" && hGuard && uOut > 0.64 && hOverRout > 0.095) : false;
    var etgDeltaU = 1 - uOut;
    var c1 = xCrossNorm != null && (1 - xCrossNorm) !== 0 ? -etgDeltaU / (1 - xCrossNorm) : null;

    return {
      id: id,
      u0: u0,
      uOut: uOut,
      uMax: uMax,
      downCrossings: down,
      upCrossings: up,
      outerViable: uOut < 1,
      cdc: u0 < 0,
      xCross: xCross,
      xCrossNorm: xCrossNorm,
      u075: u075,
      hOverRout: hOverRout,
      hGuard: hGuard,
      lGap: gap,
      gScalar: gScalar,
      priorityL: priorityL,
      lateLoad: lateLoad,
      c1: c1,
      etgCurvatureA: xCrossNorm != null ? -0.015 + 1.029 * (1 - xCrossNorm) : null,
      ltgCurvatureA: 2.210 - 2.028 * u075
    };
  }

  function compileFrameworkExpression(expression) {
    var source = String(expression || "").trim();
    if (!source) throw new Error("Framework formula is empty.");
    if (source.length > 900) throw new Error("Formula is too long for the browser test rig.");
    if (!/^[A-Za-z0-9_+\-*/%().,\s]+$/.test(source)) {
      throw new Error("Formula can only use numbers, variables, math operators, parentheses, commas, and decimals.");
    }

    var allowed = {};
    FRAMEWORK_VARS.forEach(function (name) {
      allowed[name] = true;
    });
    Object.keys(FRAMEWORK_FUNCS).forEach(function (name) {
      allowed[name] = true;
    });

    var names = source.match(/[A-Za-z_][A-Za-z0-9_]*/g) || [];
    for (var i = 0; i < names.length; i += 1) {
      if (!allowed[names[i]]) {
        throw new Error("Unknown formula token: " + names[i]);
      }
    }

    var varLines = FRAMEWORK_VARS.map(function (name) {
      return "var " + name + " = vars." + name + ";";
    }).join("");
    var fnLines = Object.keys(FRAMEWORK_FUNCS).map(function (name) {
      return "var " + name + " = fns." + name + ";";
    }).join("");
    return {
      source: source,
      fn: new Function("vars", "fns", '"use strict";' + varLines + fnLines + "return (" + source + ");")
    };
  }

  function frameworkVariables(curve, point) {
    var leff = Number.isFinite(curve.leff) ? curve.leff : curve.rOut;
    var h = Number.isFinite(curve.h) ? curve.h : Math.max(0.1, curve.rOut / 3.9);
    var memory = Number.isFinite(curve.memoryLoad) ? curve.memoryLoad : curve.rOut / h;
    var vObs = Number.isFinite(point.vObs) ? point.vObs : point.vTotal;
    return {
      r: point.r,
      x: point.r / curve.rOut,
      h: h,
      rOut: curve.rOut,
      fGas: Number.isFinite(curve.fGasOut) ? curve.fGasOut : 0,
      fGasOut: Number.isFinite(curve.fGasOut) ? curve.fGasOut : 0,
      leff: leff,
      memory: memory,
      q: Number.isFinite(curve.q) ? curve.q : CONST.qDefault,
      gamma0: CONST.gamma0,
      rMax: CONST.rMax,
      mlDisk: CONST.mlDisk,
      mlBulge: CONST.mlBulge,
      vGas: point.vGas || 0,
      vDisk: point.vDisk || 0,
      vBulge: point.vBulge || 0,
      vBar: point.vBar || 0,
      vObs: vObs,
      uObs: point.u,
      pi: Math.PI,
      e: Math.E
    };
  }

  function scoreFrameworkCurve(curve, compiled) {
    var sse = 0;
    var baselineSse = 0;
    var count = 0;
    var invalid = 0;
    var scoredPoints = [];

    curve.points.forEach(function (point) {
      var target = Number.isFinite(point.vObs) ? point.vObs : point.vTotal;
      var support2;
      try {
        support2 = compiled.fn(frameworkVariables(curve, point), FRAMEWORK_FUNCS);
      } catch (error) {
        invalid += 1;
        support2 = 0;
      }

      if (!Number.isFinite(support2)) {
        invalid += 1;
        support2 = 0;
      }

      support2 = Math.max(0, support2);
      var custom = Math.sqrt(Math.max(0, point.vBar * point.vBar + support2));
      var residual = custom - target;
      var baselineResidual = point.vTotal - target;
      sse += residual * residual;
      baselineSse += baselineResidual * baselineResidual;
      count += 1;
      scoredPoints.push({
        r: point.r,
        vCustom: custom,
        residual: residual,
        support2: support2
      });
    });

    var customRmse = count ? Math.sqrt(sse / count) : NaN;
    var baselineRmse = Number.isFinite(curve.rmse) ? curve.rmse : (count ? Math.sqrt(baselineSse / count) : NaN);
    return {
      curveName: curve.name,
      curveKind: curve.kind,
      expression: compiled.source,
      rmse: customRmse,
      baselineRmse: baselineRmse,
      delta: customRmse - baselineRmse,
      invalidCount: invalid,
      points: scoredPoints
    };
  }

  function currentFrameworkScore() {
    var score = state.framework.current;
    if (!score || !state.curve) return null;
    if (score.curveName !== state.curve.name || score.curveKind !== state.curve.kind) return null;
    return score;
  }

  function scoreCurrentFramework() {
    if (!state.framework.compiled || !state.curve) return;
    try {
      state.framework.current = scoreFrameworkCurve(state.curve, state.framework.compiled);
      state.framework.error = null;
    } catch (error) {
      state.framework.current = null;
      state.framework.error = error.message;
    }
  }

  function applyFrameworkExpression() {
    var expression = $("frameworkFormula").value;
    try {
      var previous = state.framework.expression;
      state.framework.compiled = compileFrameworkExpression(expression);
      state.framework.expression = state.framework.compiled.source;
      if (state.framework.expression !== previous) {
        state.framework.batch = [];
        state.framework.batchSummary = null;
      }
      state.framework.error = null;
      scoreCurrentFramework();
      updateDiagnostics();
      drawPlots();
      updateFrameworkPanel();
    } catch (error) {
      state.framework.error = error.message;
      state.framework.current = null;
      updateFrameworkPanel();
    }
  }

  function updateFrameworkPanel() {
    if (!$("frameworkStatus")) return;
    var score = currentFrameworkScore();
    var batch = state.framework.batchSummary;
    var error = state.framework.error;
    var note = $("frameworkNote");
    var table = $("frameworkTable");

    if (error) {
      $("frameworkStatus").textContent = "formula error";
      $("frameworkRmse").textContent = "--";
      $("frameworkMtsRmse").textContent = "--";
      $("frameworkDelta").textContent = "--";
      $("frameworkDelta").className = "";
      $("frameworkWins").textContent = batch ? batch.wins + "/" + batch.count : "--";
      note.textContent = error;
      table.innerHTML = "";
      return;
    }

    $("frameworkStatus").textContent = batch ? "batch ready" : "current ready";
    $("frameworkRmse").textContent = score ? fmt(score.rmse, 2) : "--";
    $("frameworkMtsRmse").textContent = score ? fmt(score.baselineRmse, 2) : "--";
    $("frameworkDelta").textContent = score ? fmt(score.delta, 2) : "--";
    $("frameworkDelta").className = score && score.delta < 0 ? "delta-good" : (score && score.delta > 0 ? "delta-bad" : "");
    $("frameworkWins").textContent = batch ? batch.wins + "/" + batch.count : "--";

    if (batch) {
      note.textContent = "Batch complete: " + batch.wins + " / " + batch.count + " LTGs beat baseline. Median delta " + fmt(batch.medianDelta, 2) + " km/s.";
    } else if (score) {
      note.textContent = "Formula ready. " + (score.invalidCount ? score.invalidCount + " invalid points were clamped." : "All active points evaluated.");
    } else {
      note.textContent = "Use variables like r, h, rOut, leff, memory, vGas, vDisk, vBulge, vBar, vObs, and uObs.";
    }

    if (!state.framework.batch.length) {
      table.innerHTML = '<div class="framework-row"><strong>Batch not run</strong><span>--</span><span>--</span></div>';
      return;
    }

    table.innerHTML = "";
    state.framework.batch.slice(0, 10).forEach(function (row) {
      var item = document.createElement("div");
      item.className = "framework-row";
      item.innerHTML =
        "<strong>" + row.name + "</strong>" +
        "<span>" + fmt(row.customRmse, 1) + "</span>" +
        '<span class="' + (row.delta < 0 ? "delta-good" : (row.delta > 0 ? "delta-bad" : "")) + '">' + fmt(row.delta, 1) + "</span>";
      table.appendChild(item);
    });
  }

  function runFrameworkBatch() {
    applyFrameworkExpression();
    if (state.framework.error || !state.framework.compiled) return;

    var rows = [];
    (window.MTS_SAMPLES || []).forEach(function (sample, index) {
      try {
        var curve = parseRotmod(sample.text, sample.name);
        var route = classifyRoute(curve.points, curve);
        var score = scoreFrameworkCurve(curve, state.framework.compiled);
        rows.push({
          index: index,
          name: curve.name,
          route: route.id,
          customRmse: score.rmse,
          mtsRmse: score.baselineRmse,
          delta: score.delta,
          invalidCount: score.invalidCount,
          h: curve.h,
          rOut: curve.rOut,
          uOut: route.uOut,
          lateLoad: route.lateLoad,
          cdc: route.cdc,
          outerViable: route.outerViable
        });
      } catch (error) {
        rows.push({
          index: index,
          name: cleanGalaxyName(sample.name),
          route: "error",
          customRmse: NaN,
          mtsRmse: NaN,
          delta: NaN,
          invalidCount: 0,
          error: error.message
        });
      }
    });

    var valid = rows.filter(function (row) {
      return Number.isFinite(row.delta);
    });
    valid.sort(function (a, b) {
      return a.delta - b.delta;
    });
    state.framework.batch = valid.concat(rows.filter(function (row) {
      return !Number.isFinite(row.delta);
    }));

    var wins = valid.filter(function (row) { return row.delta < -0.001; }).length;
    var meanDelta = valid.reduce(function (sum, row) { return sum + row.delta; }, 0) / Math.max(1, valid.length);
    var medianDelta = valid.length ? valid[Math.floor(valid.length / 2)].delta : NaN;
    state.framework.batchSummary = {
      count: valid.length,
      wins: wins,
      meanDelta: meanDelta,
      medianDelta: medianDelta,
      expression: state.framework.expression
    };
    $("frameworkNote").textContent = "Batch complete: " + wins + " / " + valid.length + " LTGs beat the MTS baseline for this formula.";
    updateFrameworkPanel();
  }

  function updateDiagnostics() {
    var curve = state.curve;
    var route = state.route;
    if (!curve || !route) return;

    $("sceneTitle").textContent = curve.kind === "synthetic" ? "Synthetic transport disk" : curve.name;
    $("sceneSubtitle").textContent = curve.kind === "etg"
      ? "ETG high-res disk/bulge outer-chain and Stage-4 diagnostics"
      : (curve.kind === "observed" ? "LTG ROTMOD overlay using locked MTS memory law" : "Live particles from the computed circular velocity field");
    $("routePill").textContent = route.id;

    if (curve.kind === "etg") {
      $("metricLeffLabel").textContent = "R80";
      $("metricLeff").textContent = fmt(curve.stage4.r80, 2);
      $("metricLeffUnit").textContent = "kpc";
      $("metricMemoryLabel").textContent = "Stage-4 dR80";
      $("metricMemory").textContent = fmt(curve.stage4.residualR80, 3);
      $("metricMemoryUnit").textContent = "log residual";
      $("metricUoutLabel").textContent = "u_out";
      $("metricUout").textContent = fmt(route.uOut, 3);
      $("metricUoutUnit").textContent = "outer gate";
      $("metricRmseLabel").textContent = "logy";
      $("metricRmse").textContent = fmt(curve.stage4.logy, 3);
      $("metricRmseUnit").textContent = "ln(Vdisk^2/rout)";
    } else {
      $("metricLeffLabel").textContent = "L_eff";
      $("metricLeff").textContent = fmt(curve.leff, 2);
      $("metricLeffUnit").textContent = "kpc";
      $("metricMemoryLabel").textContent = "Memory load";
      $("metricMemory").textContent = fmt(curve.memoryLoad, 2);
      $("metricMemoryUnit").textContent = "(1-fgas) rout/h";
      $("metricUoutLabel").textContent = "u_out";
      $("metricUout").textContent = fmt(route.uOut, 3);
      $("metricUoutUnit").textContent = "outer gate";
      $("metricRmseLabel").textContent = "RMSE";
      $("metricRmse").textContent = curve.rmse == null ? "--" : fmt(curve.rmse, 2);
      $("metricRmseUnit").textContent = "km/s";
    }

    $("routeCount").textContent = route.downCrossings + " down / " + route.upCrossings + " up";

    var routeRows = curve.kind === "etg"
      ? [
        ["outer viable", route.outerViable ? "yes" : "no", route.outerViable],
        ["max u(r)", fmt(route.uMax, 3), route.uMax >= 1],
        ["u_out", fmt(route.uOut, 3), route.uOut < 1],
        ["route", route.id, true]
      ]
      : [
        ["outer viable", route.outerViable ? "yes" : "no", route.outerViable],
        ["CDC sign", route.cdc ? "u0 < 0" : "u0 >= 0", route.cdc],
        ["u(R0)", fmt(route.u0, 3), route.u0 < 0],
        ["max u(r)", fmt(route.uMax, 3), route.uMax >= 1],
        ["u_out", fmt(route.uOut, 3), route.uOut < 1],
        ["route", route.id, true]
      ];

    if (route.xCrossNorm != null) {
      routeRows.push(["x_cross", fmt(route.xCrossNorm, 3), true]);
      routeRows.push(["u_0.75", fmt(route.u075, 3), route.u075 > 0.64]);
    }

    if (curve.kind === "observed" && route.xCrossNorm != null) {
      routeRows.push(["L_gap", fmt(route.lGap, 2) + " kpc", true]);
      routeRows.push(["g = memory*x", fmt(route.gScalar, 2), true]);
      routeRows.push(["Priority L MAE", fmt(route.priorityL, 1) + " km/s", true]);
      routeRows.push(["late-load final", route.lateLoad ? "flagged" : "clear", route.lateLoad]);
      routeRows.push(["LTG curvature A", fmt(route.ltgCurvatureA, 3), true]);
    }

    if (curve.kind === "etg") {
      routeRows.push(["h", fmt(curve.h, 3) + " kpc", true]);
      routeRows.push(["R90", fmt(curve.stage4.r90, 2) + " kpc", true]);
      routeRows.push(["Sigma80-100", fmt(curve.stage4.sigma80, 3), true]);
      routeRows.push(["Stage4 R80 pred", fmt(curve.stage4.stageR80, 3), true]);
      routeRows.push(["Stage4 R90 pred", fmt(curve.stage4.stageR90, 3), true]);
      if (route.xCrossNorm != null) {
        routeRows.push(["c1 slope law", fmt(route.c1, 3), true]);
        routeRows.push(["ETG curvature A", fmt(route.etgCurvatureA, 3), true]);
      }
    }

    var stack = $("routeStack");
    stack.innerHTML = "";
    routeRows.forEach(function (row) {
      var item = document.createElement("div");
      item.className = "route-item" + (row[2] ? " active" : "");
      item.innerHTML = '<span class="route-dot"></span><span>' + row[0] + '</span><span class="route-value">' + row[1] + '</span>';
      stack.appendChild(item);
    });

    var frameworkScore = currentFrameworkScore();
    if (curve.kind === "observed") {
      $("curveLegend").textContent = frameworkScore ? "observed + MTS + custom" : "observed + model";
      $("residualLegend").textContent = frameworkScore ? "custom - observed" : "model - observed";
    } else if (curve.kind === "etg") {
      $("curveLegend").textContent = frameworkScore ? "obs + support + custom" : "obs + baryon + support";
      $("residualLegend").textContent = frameworkScore ? "custom - observed" : "Stage-4 log residual";
    } else {
      $("curveLegend").textContent = frameworkScore ? "MTS + custom" : "model";
      $("residualLegend").textContent = frameworkScore ? "custom - MTS" : "support share";
    }
    updateFrameworkPanel();
  }

  function drawPlots() {
    if (!state.curve) return;
    drawCurvePlot();
    drawUPlot();
    drawResidualPlot();
  }

  function svgEl(name, attrs) {
    var el = document.createElementNS("http://www.w3.org/2000/svg", name);
    Object.keys(attrs || {}).forEach(function (key) {
      el.setAttribute(key, attrs[key]);
    });
    return el;
  }

  function makePath(points, xFn, yFn) {
    return points.map(function (p, i) {
      return (i === 0 ? "M" : "L") + xFn(p).toFixed(2) + " " + yFn(p).toFixed(2);
    }).join(" ");
  }

  function drawPlotFrame(svg, width, height, xTicks, yTicks, xScale, yScale, xMax, yMin, yMax) {
    svg.innerHTML = "";
    var plot = { left: 42, right: width - 16, top: 18, bottom: height - 34 };
    for (var i = 0; i <= xTicks; i += 1) {
      var xVal = xMax * i / xTicks;
      var x = xScale(xVal);
      svg.appendChild(svgEl("line", { class: "plot-grid", x1: x, y1: plot.top, x2: x, y2: plot.bottom }));
      svg.appendChild(svgEl("text", { class: "plot-label", x: x - 8, y: height - 12 })).textContent = fmt(xVal, 0);
    }
    for (var j = 0; j <= yTicks; j += 1) {
      var yVal = yMin + (yMax - yMin) * j / yTicks;
      var y = yScale(yVal);
      svg.appendChild(svgEl("line", { class: "plot-grid", x1: plot.left, y1: y, x2: plot.right, y2: y }));
      svg.appendChild(svgEl("text", { class: "plot-label", x: 5, y: y + 3 })).textContent = fmt(yVal, yMax - yMin > 4 ? 0 : 1);
    }
    svg.appendChild(svgEl("line", { class: "plot-axis", x1: plot.left, y1: plot.bottom, x2: plot.right, y2: plot.bottom }));
    svg.appendChild(svgEl("line", { class: "plot-axis", x1: plot.left, y1: plot.top, x2: plot.left, y2: plot.bottom }));
    return plot;
  }

  function drawCurvePlot() {
    var svg = $("curvePlot");
    var width = 420;
    var height = 260;
    var points = state.curve.points;
    var frameworkScore = currentFrameworkScore();
    var xMax = state.curve.rOut;
    var yMax = 0;
    points.forEach(function (p) {
      yMax = Math.max(yMax, p.vTotal, p.vBar, p.vMts, p.vObs || 0);
    });
    if (frameworkScore) {
      frameworkScore.points.forEach(function (p) {
        yMax = Math.max(yMax, p.vCustom);
      });
    }
    yMax = Math.ceil(yMax / 25) * 25 + 25;
    var plot = {
      left: 42,
      right: width - 16,
      top: 18,
      bottom: height - 34
    };
    var xScale = function (x) { return plot.left + (x / xMax) * (plot.right - plot.left); };
    var yScale = function (y) { return plot.bottom - (y / yMax) * (plot.bottom - plot.top); };
    drawPlotFrame(svg, width, height, 4, 4, xScale, yScale, xMax, 0, yMax);

    svg.appendChild(svgEl("path", { class: "line-bar", d: makePath(points, function (p) { return xScale(p.r); }, function (p) { return yScale(p.vBar); }) }));
    svg.appendChild(svgEl("path", { class: "line-mts", d: makePath(points, function (p) { return xScale(p.r); }, function (p) { return yScale(p.vMts); }) }));
    svg.appendChild(svgEl("path", { class: "line-total", d: makePath(points, function (p) { return xScale(p.r); }, function (p) { return yScale(p.vTotal); }) }));
    if (frameworkScore) {
      svg.appendChild(svgEl("path", { class: "line-custom", d: makePath(frameworkScore.points, function (p) { return xScale(p.r); }, function (p) { return yScale(p.vCustom); }) }));
    }

    if (state.curve.kind === "observed" || state.curve.kind === "etg") {
      svg.appendChild(svgEl("path", { class: "line-obs", d: makePath(points, function (p) { return xScale(p.r); }, function (p) { return yScale(p.vObs); }) }));
      (state.curve.observedPoints || points).forEach(function (p) {
        svg.appendChild(svgEl("circle", { class: "dot-obs", cx: xScale(p.r), cy: yScale(p.vObs), r: 2.6 }));
      });
    }
  }

  function drawUPlot() {
    var svg = $("uPlot");
    var width = 420;
    var height = 230;
    var points = state.curve.points;
    var xMax = state.curve.rOut;
    var minU = Math.min.apply(null, points.map(function (p) { return p.u; }));
    var maxU = Math.max.apply(null, points.map(function (p) { return p.u; }));
    var yMin = Math.floor(Math.min(minU, 0) * 2) / 2 - 0.15;
    var yMax = Math.ceil(Math.max(maxU, 1) * 2) / 2 + 0.15;
    if (yMax - yMin < 1.2) yMax = yMin + 1.2;
    var plot = {
      left: 42,
      right: width - 16,
      top: 18,
      bottom: height - 34
    };
    var xScale = function (x) { return plot.left + (x / xMax) * (plot.right - plot.left); };
    var yScale = function (y) { return plot.bottom - ((y - yMin) / (yMax - yMin)) * (plot.bottom - plot.top); };
    drawPlotFrame(svg, width, height, 4, 4, xScale, yScale, xMax, yMin, yMax);
    svg.appendChild(svgEl("line", { class: "threshold-line", x1: plot.left, y1: yScale(1), x2: plot.right, y2: yScale(1) }));
    svg.appendChild(svgEl("path", { class: "line-u", d: makePath(points, function (p) { return xScale(p.r); }, function (p) { return yScale(p.u); }) }));
  }

  function drawResidualPlot() {
    var svg = $("residualPlot");
    var width = 420;
    var height = 220;
    var curve = state.curve;
    var xMax = curve.rOut;
    var frameworkScore = currentFrameworkScore();
    var points;
    var yMin;
    var yMax;

    if (frameworkScore) {
      points = frameworkScore.points.map(function (p) {
        return { r: p.r, value: p.residual };
      });
      var maxAbs = Math.max.apply(null, points.map(function (p) { return Math.abs(p.value); }));
      maxAbs = Math.max(5, Math.ceil(maxAbs / 5) * 5);
      yMin = -maxAbs;
      yMax = maxAbs;
    } else if (curve.kind === "observed") {
      points = curve.points.map(function (p) {
        return { r: p.r, value: p.vTotal - p.vObs };
      });
      var obsAbs = Math.max.apply(null, points.map(function (p) { return Math.abs(p.value); }));
      obsAbs = Math.max(5, Math.ceil(obsAbs / 5) * 5);
      yMin = -obsAbs;
      yMax = obsAbs;
    } else if (curve.kind === "etg") {
      points = [
        { r: 0.8 * xMax, value: curve.stage4.residualR80 },
        { r: 0.9 * xMax, value: curve.stage4.residualR90 }
      ];
      var etgAbs = Math.max(Math.abs(curve.stage4.residualR80), Math.abs(curve.stage4.residualR90));
      etgAbs = Math.max(0.2, Math.ceil(etgAbs * 10) / 10);
      yMin = -etgAbs;
      yMax = etgAbs;
    } else {
      points = curve.points.map(function (p) {
        return { r: p.r, value: p.vTotal > 0 ? p.vMts / p.vTotal : 0 };
      });
      yMin = 0;
      yMax = 1;
    }

    var plot = {
      left: 42,
      right: width - 16,
      top: 18,
      bottom: height - 34
    };
    var xScale = function (x) { return plot.left + (x / xMax) * (plot.right - plot.left); };
    var yScale = function (y) { return plot.bottom - ((y - yMin) / (yMax - yMin)) * (plot.bottom - plot.top); };
    drawPlotFrame(svg, width, height, 4, 4, xScale, yScale, xMax, yMin, yMax);

    if (yMin < 0 && yMax > 0) {
      svg.appendChild(svgEl("line", { class: "zero-line", x1: plot.left, y1: yScale(0), x2: plot.right, y2: yScale(0) }));
    }

    svg.appendChild(svgEl("path", { class: "line-residual", d: makePath(points, function (p) { return xScale(p.r); }, function (p) { return yScale(p.value); }) }));
    if (curve.kind !== "synthetic" && points.length <= 90) {
      points.forEach(function (p) {
        svg.appendChild(svgEl("circle", { class: "dot-residual", cx: xScale(p.r), cy: yScale(p.value), r: 2.8 }));
      });
    }
  }

  function interpVelocity(r) {
    var curve = state.curve;
    if (!curve || !curve.points.length) return 0;
    var points = curve.points;
    if (r <= points[0].r) return effectiveVelocity(points[0]);
    if (r >= points[points.length - 1].r) return effectiveVelocity(points[points.length - 1]);
    for (var i = 1; i < points.length; i += 1) {
      if (points[i].r >= r) {
        var a = points[i - 1];
        var b = points[i];
        var t = (r - a.r) / (b.r - a.r);
        return effectiveVelocity(a) * (1 - t) + effectiveVelocity(b) * t;
      }
    }
    return effectiveVelocity(points[points.length - 1]);
  }

  function effectiveVelocity(point) {
    var p = readParams();
    if (state.curve && state.curve.kind === "etg") return point.vTotal;
    return p.showMtsOnly ? point.vMts : point.vTotal;
  }

  function generateParticles() {
    if (!state.curve) return;
    state.particles = [];
    var h = state.curve.h || 3;
    var rOut = state.curve.rOut || 25;
    var count = Math.min(6200, Math.max(2800, Math.round(1750 + rOut * 95)));
    var trunc = 1 - Math.exp(-rOut / h);
    for (var i = 0; i < count; i += 1) {
      var isGas = seededRandom() < 0.18;
      var u = seededRandom();
      var r = -h * Math.log(Math.max(0.00001, 1 - u * trunc));
      r = clamp(r + (seededRandom() - 0.5) * 0.08 * h, 0.06, rOut);
      var arm = Math.floor(seededRandom() * 3);
      var theta = seededRandom() * Math.PI * 2 + arm * (Math.PI * 2 / 3) + 1.15 * Math.log(1 + r / h);
      theta += (seededRandom() - 0.5) * (isGas ? 0.42 : 0.78);
      state.particles.push({
        r: r,
        theta: theta,
        phase: seededRandom() * Math.PI * 2,
        drift: (seededRandom() - 0.5) * 0.002,
        gas: isGas,
        alpha: isGas ? 0.58 + seededRandom() * 0.34 : 0.34 + seededRandom() * 0.38,
        size: isGas ? 1.15 + seededRandom() * 1.8 : 0.7 + seededRandom() * 1.4
      });
    }
  }

  function resizeCanvas() {
    var rect = canvas.getBoundingClientRect();
    var dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.max(400, Math.floor(rect.width * dpr));
    canvas.height = Math.max(320, Math.floor(rect.height * dpr));
    state.canvasScale = dpr;
  }

  function drawGalaxy(timestamp) {
    if (!state.lastFrame) state.lastFrame = timestamp;
    var dt = Math.min(48, timestamp - state.lastFrame) / 16.667;
    state.lastFrame = timestamp;
    var p = readParams();
    var w = canvas.width;
    var hPx = canvas.height;
    var dpr = state.canvasScale;
    var cx = w * 0.5;
    var cy = hPx * 0.53;
    var rOut = state.curve ? state.curve.rOut : 25;
    var scale = Math.min(w, hPx) * 0.43 / rOut;

    ctx.fillStyle = "#0e100d";
    ctx.fillRect(0, 0, w, hPx);

    drawCanvasGrid(cx, cy, scale, rOut, dpr);

    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    for (var i = 0; i < state.particles.length; i += 1) {
      var part = state.particles[i];
      var v = interpVelocity(part.r);
      var omega = (v / Math.max(part.r, 0.4)) * 0.0022 * p.speed;
      part.theta += (omega + part.drift) * dt;
      var wobble = Math.sin(timestamp * 0.0005 + part.phase) * 0.018 * part.r;
      var rr = part.r + wobble;
      var x = cx + Math.cos(part.theta) * rr * scale;
      var y = cy + Math.sin(part.theta) * rr * scale * 0.63;
      var radius = part.size * dpr;
      ctx.beginPath();
      ctx.arc(x, y, radius, 0, Math.PI * 2);
      if (part.gas) {
        ctx.fillStyle = "rgba(94, 227, 194, " + part.alpha.toFixed(3) + ")";
      } else {
        var warm = 178 + Math.floor(60 * (1 - part.r / rOut));
        ctx.fillStyle = "rgba(255, " + warm + ", 112, " + part.alpha.toFixed(3) + ")";
      }
      ctx.fill();
    }
    ctx.restore();

    drawCanvasCore(cx, cy, scale, dpr);
    requestAnimationFrame(drawGalaxy);
  }

  function drawCanvasGrid(cx, cy, scale, rOut, dpr) {
    ctx.save();
    ctx.strokeStyle = "rgba(238, 241, 232, 0.08)";
    ctx.lineWidth = 1 * dpr;
    for (var i = 1; i <= 4; i += 1) {
      ctx.beginPath();
      ctx.ellipse(cx, cy, (rOut * i / 4) * scale, (rOut * i / 4) * scale * 0.63, 0, 0, Math.PI * 2);
      ctx.stroke();
    }
    ctx.strokeStyle = "rgba(214, 255, 99, 0.14)";
    ctx.beginPath();
    ctx.moveTo(cx - rOut * scale, cy);
    ctx.lineTo(cx + rOut * scale, cy);
    ctx.stroke();
    ctx.restore();
  }

  function drawCanvasCore(cx, cy, scale, dpr) {
    var grd = ctx.createRadialGradient(cx, cy, 0, cx, cy, 28 * dpr);
    grd.addColorStop(0, "rgba(255, 233, 155, 0.92)");
    grd.addColorStop(0.45, "rgba(243, 155, 109, 0.28)");
    grd.addColorStop(1, "rgba(243, 155, 109, 0)");
    ctx.fillStyle = grd;
    ctx.beginPath();
    ctx.arc(cx, cy, 30 * dpr, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = "rgba(214, 255, 99, 0.95)";
    ctx.beginPath();
    ctx.arc(cx, cy, 2.2 * dpr, 0, Math.PI * 2);
    ctx.fill();
  }

  function setMode(mode) {
    state.mode = mode;
    document.querySelectorAll(".mode-button").forEach(function (button) {
      button.classList.toggle("active", button.dataset.mode === mode);
    });
    document.querySelectorAll(".synthetic-only").forEach(function (el) {
      el.classList.toggle("hidden", mode !== "synthetic");
    });
    document.querySelectorAll(".observed-only").forEach(function (el) {
      el.classList.toggle("hidden", mode !== "observed");
    });
    document.querySelectorAll(".etg-only").forEach(function (el) {
      el.classList.toggle("hidden", mode !== "etg");
    });
    document.querySelectorAll(".ltg-browser-only").forEach(function (el) {
      el.classList.toggle("hidden", mode !== "observed");
    });
    if (mode === "synthetic") {
      buildSyntheticCurve();
    } else if (mode === "etg") {
      loadSelectedEtg();
    } else {
      loadSelectedSample();
    }
    generateParticles();
    updateLtgBrowser();
  }

  function loadObservedCurve(curve) {
    state.curve = curve;
    state.observed = curve;
    state.route = classifyRoute(curve.points, curve);
    scoreCurrentFramework();
    updateDiagnostics();
    drawPlots();
    state.seed = hashName(curve.name);
    generateParticles();
    if (curve.kind === "observed") updateLtgBrowser();
  }

  function hashName(name) {
    var hash = 2166136261;
    for (var i = 0; i < name.length; i += 1) {
      hash ^= name.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }
    return hash >>> 0;
  }

  function setupSamples() {
    var select = $("sampleSelect");
    select.innerHTML = "";
    var samples = window.MTS_SAMPLES || [];
    state.ltgIndex = [];
    if (!samples.length) {
      var option = document.createElement("option");
      option.value = "";
      option.textContent = "No bundled samples";
      select.appendChild(option);
      return;
    }
    samples.forEach(function (sample, index) {
      var meta = analyzeLtgSample(sample, index);
      state.ltgIndex.push(meta);
      var option = document.createElement("option");
      option.value = String(index);
      option.textContent = meta.name;
      select.appendChild(option);
    });
  }

  function filteredLtgIndex() {
    var browser = state.ltgBrowser;
    var search = browser.search.trim().toLowerCase();
    var rows = state.ltgIndex.filter(function (row) {
      if (search && row.name.toLowerCase().indexOf(search) === -1) return false;
      if (browser.route !== "all" && row.route !== browser.route) return false;
      if (browser.hunt === "late" && !row.lateLoad) return false;
      if (browser.hunt === "cdc" && !row.cdc) return false;
      if (browser.hunt === "single" && row.route !== "buffered single-crossing") return false;
      if (browser.hunt === "infeasible" && row.route !== "outer-infeasible") return false;
      if (browser.hunt === "worst" && !Number.isFinite(row.rmse)) return false;
      if (browser.hunt === "best" && !Number.isFinite(row.rmse)) return false;
      return true;
    });

    var sort = browser.hunt === "worst" ? "rmse-desc" : (browser.hunt === "best" ? "rmse-asc" : browser.sort);
    rows.sort(function (a, b) {
      if (sort === "name-asc") return a.name.localeCompare(b.name);
      if (sort === "rmse-asc") return safeNumber(a.rmse, Infinity) - safeNumber(b.rmse, Infinity);
      if (sort === "uout-desc") return safeNumber(b.uOut, -Infinity) - safeNumber(a.uOut, -Infinity);
      if (sort === "priority-desc") return safeNumber(b.priorityL, -Infinity) - safeNumber(a.priorityL, -Infinity);
      if (sort === "xcross-desc") return safeNumber(b.xCross, -Infinity) - safeNumber(a.xCross, -Infinity);
      return safeNumber(b.rmse, -Infinity) - safeNumber(a.rmse, -Infinity);
    });

    if (browser.hunt === "worst" || browser.hunt === "best") {
      rows = rows.slice(0, 20);
    }
    return rows;
  }

  function safeNumber(value, fallback) {
    return Number.isFinite(value) ? value : fallback;
  }

  function updateLtgBrowser() {
    var table = $("galaxyTable");
    if (!table) return;
    var rows = filteredLtgIndex();
    $("ltgBrowserCount").textContent = rows.length + " / " + state.ltgIndex.length;
    updateLtgRouteSummary();
    table.innerHTML = "";

    rows.slice(0, 90).forEach(function (row) {
      var button = document.createElement("button");
      button.type = "button";
      button.className = "galaxy-row" + (state.curve && state.curve.name === row.name ? " active" : "");
      button.innerHTML =
        '<span class="galaxy-name">' + row.name + '</span>' +
        '<span class="route-badge">' + row.route + '</span>' +
        '<span class="table-number">' + fmt(row.rmse, 1) + '</span>' +
        '<span class="table-number">' + fmt(row.uOut, 2) + '</span>';
      button.addEventListener("click", function () {
        $("sampleSelect").value = String(row.index);
        setMode("observed");
        loadSelectedSample();
      });
      table.appendChild(button);
    });
  }

  function updateLtgRouteSummary() {
    var summary = $("ltgRouteSummary");
    if (!summary) return;
    var counts = {
      "low-load": 0,
      "buffered upward-crossing": 0,
      "buffered single-crossing": 0,
      "outer-infeasible": 0,
      "CDC-low-load": 0,
      late: 0
    };
    state.ltgIndex.forEach(function (row) {
      if (counts[row.route] != null) counts[row.route] += 1;
      if (row.lateLoad) counts.late += 1;
    });
    var chips = [
      ["Low", counts["low-load"]],
      ["Upward", counts["buffered upward-crossing"]],
      ["Single", counts["buffered single-crossing"]],
      ["Infeasible", counts["outer-infeasible"]],
      ["CDC-low", counts["CDC-low-load"]],
      ["Late flag", counts.late]
    ];
    summary.innerHTML = chips.map(function (chip) {
      return '<div class="summary-chip"><span>' + chip[0] + '</span><strong>' + chip[1] + '</strong></div>';
    }).join("");
  }

  function setupEtgSamples() {
    var select = $("etgSelect");
    select.innerHTML = "";
    var samples = window.MTS_ETG_SAMPLES || [];
    if (!samples.length) {
      var option = document.createElement("option");
      option.value = "";
      option.textContent = "No bundled ETGs";
      select.appendChild(option);
      return;
    }
    samples.forEach(function (sample, index) {
      var option = document.createElement("option");
      option.value = String(index);
      option.textContent = sample.name;
      select.appendChild(option);
    });
  }

  function loadSelectedEtg() {
    var samples = window.MTS_ETG_SAMPLES || [];
    var select = $("etgSelect");
    if (!samples.length) return;
    var index = select.value === "" ? 0 : Number(select.value);
    var sample = samples[index];
    if (sample) {
      loadObservedCurve(parseEtgSample(sample));
    }
  }

  function loadSelectedSample() {
    var samples = window.MTS_SAMPLES || [];
    var select = $("sampleSelect");
    if (!samples.length || !select.value) {
      if (samples.length && select.value === "0") {
        loadObservedCurve(parseRotmod(samples[0].text, samples[0].name));
      }
      return;
    }
    var sample = samples[Number(select.value)];
    if (sample) {
      loadObservedCurve(parseRotmod(sample.text, sample.name));
      $("pasteInput").value = sample.text;
    }
  }

  function slugify(value) {
    return String(value || "mts-galaxy")
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 80) || "mts-galaxy";
  }

  function exportCell(value) {
    if (value == null) return "";
    if (typeof value === "boolean") return value ? "true" : "false";
    if (typeof value === "number") return Number.isFinite(value) ? String(Number(value.toPrecision(10))) : "";
    return String(value);
  }

  function csvEscape(value) {
    var text = exportCell(value);
    if (/[",\r\n]/.test(text)) {
      return '"' + text.replace(/"/g, '""') + '"';
    }
    return text;
  }

  function rowsToCsv(headers, rows) {
    return [headers.map(csvEscape).join(",")].concat(rows.map(function (row) {
      return headers.map(function (key) {
        return csvEscape(row[key]);
      }).join(",");
    })).join("\r\n");
  }

  function downloadText(filename, text, mime) {
    var blob = new Blob([text], { type: mime || "text/plain;charset=utf-8" });
    var url = URL.createObjectURL(blob);
    var anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(function () {
      URL.revokeObjectURL(url);
    }, 1000);
    $("exportNote").textContent = "Prepared " + filename;
  }

  function currentDiagnosticsObject() {
    var curve = state.curve;
    var route = state.route;
    var frameworkScore = currentFrameworkScore();
    return {
      generatedAt: new Date().toISOString(),
      app: "MTS Galaxy Lab",
      mode: state.mode,
      constants: CONST,
      curve: curve ? {
        kind: curve.kind,
        name: curve.name,
        h: curve.h,
        rOut: curve.rOut,
        fGasOut: curve.fGasOut,
        q: curve.q,
        leff: curve.leff,
        memoryLoad: curve.memoryLoad,
        rmse: curve.rmse,
        pointCount: curve.points.length,
        stage4: curve.stage4 || null
      } : null,
      route: route ? {
        id: route.id,
        u0: route.u0,
        uOut: route.uOut,
        uMax: route.uMax,
        downCrossings: route.downCrossings,
        upCrossings: route.upCrossings,
        outerViable: route.outerViable,
        cdc: route.cdc,
        xCross: route.xCross,
        xCrossNorm: route.xCrossNorm,
        u075: route.u075,
        hOverRout: route.hOverRout,
        hGuard: route.hGuard,
        lGap: route.lGap,
        gScalar: route.gScalar,
        priorityL: route.priorityL,
        lateLoad: route.lateLoad,
        c1: route.c1,
        etgCurvatureA: route.etgCurvatureA,
        ltgCurvatureA: route.ltgCurvatureA
      } : null,
      ltgBrowser: {
        filters: state.ltgBrowser,
        filteredCount: filteredLtgIndex().length,
        totalCount: state.ltgIndex.length
      },
      framework: {
        expression: state.framework.expression,
        error: state.framework.error,
        current: frameworkScore ? {
          rmse: frameworkScore.rmse,
          baselineRmse: frameworkScore.baselineRmse,
          delta: frameworkScore.delta,
          invalidCount: frameworkScore.invalidCount
        } : null,
        batchSummary: state.framework.batchSummary
      }
    };
  }

  function currentCurveCsv() {
    var curve = state.curve;
    var route = state.route;
    var frameworkScore = currentFrameworkScore();
    var headers = [
      "galaxy",
      "mode",
      "route",
      "point_index",
      "r_kpc",
      "v_obs_kms",
      "v_model_kms",
      "v_bar_kms",
      "v_mts_kms",
      "v_gas_kms",
      "v_disk_kms",
      "v_bulge_kms",
      "u",
      "residual_kms",
      "v_custom_kms",
      "custom_residual_kms"
    ];
    var rows = curve.points.map(function (p, index) {
      var frameworkPoint = frameworkScore && frameworkScore.points[index] ? frameworkScore.points[index] : null;
      return {
        galaxy: curve.name,
        mode: curve.kind,
        route: route.id,
        point_index: index,
        r_kpc: p.r,
        v_obs_kms: p.vObs,
        v_model_kms: p.vTotal,
        v_bar_kms: p.vBar,
        v_mts_kms: p.vMts,
        v_gas_kms: p.vGas,
        v_disk_kms: p.vDisk,
        v_bulge_kms: p.vBulge,
        u: p.u,
        residual_kms: Number.isFinite(p.vObs) ? p.vTotal - p.vObs : null,
        v_custom_kms: frameworkPoint ? frameworkPoint.vCustom : null,
        custom_residual_kms: frameworkPoint ? frameworkPoint.residual : null
      };
    });
    return rowsToCsv(headers, rows);
  }

  function ltgIndexCsv() {
    var headers = [
      "name",
      "route",
      "rmse_kms",
      "h_kpc",
      "r_out_kpc",
      "f_gas_out",
      "l_eff_kpc",
      "memory_load",
      "h_over_rout",
      "u0",
      "u_out",
      "u_max",
      "x_cross",
      "u_075",
      "l_gap_kpc",
      "g_memory_x",
      "priority_l_mae_kms",
      "ltg_curvature_a",
      "late_load",
      "cdc",
      "outer_viable"
    ];
    return rowsToCsv(headers, filteredLtgIndex().map(function (row) {
      return {
        name: row.name,
        route: row.route,
        rmse_kms: row.rmse,
        h_kpc: row.h,
        r_out_kpc: row.rOut,
        f_gas_out: row.fGasOut,
        l_eff_kpc: row.leff,
        memory_load: row.memoryLoad,
        h_over_rout: row.hOverRout,
        u0: row.u0,
        u_out: row.uOut,
        u_max: row.uMax,
        x_cross: row.xCross,
        u_075: row.u075,
        l_gap_kpc: row.lGap,
        g_memory_x: row.gScalar,
        priority_l_mae_kms: row.priorityL,
        ltg_curvature_a: row.ltgCurvatureA,
        late_load: row.lateLoad,
        cdc: row.cdc,
        outer_viable: row.outerViable
      };
    }));
  }

  function frameworkScoresCsv() {
    var headers = [
      "expression",
      "name",
      "route",
      "custom_rmse_kms",
      "mts_rmse_kms",
      "delta_rmse_kms",
      "invalid_points",
      "h_kpc",
      "r_out_kpc",
      "u_out",
      "late_load",
      "cdc",
      "outer_viable"
    ];
    return rowsToCsv(headers, state.framework.batch.map(function (row) {
      return {
        expression: state.framework.expression,
        name: row.name,
        route: row.route,
        custom_rmse_kms: row.customRmse,
        mts_rmse_kms: row.mtsRmse,
        delta_rmse_kms: row.delta,
        invalid_points: row.invalidCount,
        h_kpc: row.h,
        r_out_kpc: row.rOut,
        u_out: row.uOut,
        late_load: row.lateLoad,
        cdc: row.cdc,
        outer_viable: row.outerViable
      };
    }));
  }

  function svgExportStyle() {
    return [
      ".plot-axis{stroke:#9ba497;stroke-width:1;vector-effect:non-scaling-stroke}",
      ".plot-grid{stroke:#343b31;stroke-width:1;vector-effect:non-scaling-stroke}",
      ".plot-label{fill:#788171;font-size:10px;font-family:Arial,sans-serif;font-weight:650}",
      ".line-total{fill:none;stroke:#d6ff63;stroke-width:3;vector-effect:non-scaling-stroke}",
      ".line-bar{fill:none;stroke:#5ee3c2;stroke-width:2;stroke-dasharray:6 5;vector-effect:non-scaling-stroke}",
      ".line-mts{fill:none;stroke:#f39b6d;stroke-width:2;vector-effect:non-scaling-stroke}",
      ".line-custom{fill:none;stroke:#ffffff;stroke-width:2.2;stroke-dasharray:2 5;vector-effect:non-scaling-stroke}",
      ".line-obs{fill:none;stroke:#8aa8ff;stroke-width:2.5;vector-effect:non-scaling-stroke}",
      ".dot-obs{fill:#8aa8ff;stroke:#11130f;stroke-width:1}",
      ".line-u{fill:none;stroke:#d6ff63;stroke-width:2.5;vector-effect:non-scaling-stroke}",
      ".threshold-line{stroke:#ff726f;stroke-width:1.5;stroke-dasharray:5 5;vector-effect:non-scaling-stroke}",
      ".line-residual{fill:none;stroke:#8aa8ff;stroke-width:2.4;vector-effect:non-scaling-stroke}",
      ".zero-line{stroke:#aeb7a8;stroke-width:1;stroke-dasharray:4 5;vector-effect:non-scaling-stroke}",
      ".dot-residual{fill:#8aa8ff;stroke:#11130f;stroke-width:1}"
    ].join("\n");
  }

  function styledSvgMarkup(id) {
    var source = $(id);
    var clone = source.cloneNode(true);
    clone.setAttribute("xmlns", "http://www.w3.org/2000/svg");
    var style = document.createElementNS("http://www.w3.org/2000/svg", "style");
    style.textContent = svgExportStyle();
    clone.insertBefore(style, clone.firstChild);
    return new XMLSerializer().serializeToString(clone);
  }

  function htmlEscape(value) {
    return exportCell(value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function diagnosticRows() {
    var curve = state.curve;
    var route = state.route;
    var frameworkScore = currentFrameworkScore();
    var rows = [
      ["Name", curve.name],
      ["Mode", curve.kind],
      ["Route", route.id],
      ["h", fmt(curve.h, 3) + " kpc"],
      ["r_out", fmt(curve.rOut, 3) + " kpc"],
      ["u0", fmt(route.u0, 4)],
      ["u_out", fmt(route.uOut, 4)],
      ["u_max", fmt(route.uMax, 4)],
      ["x_cross", route.xCrossNorm == null ? "--" : fmt(route.xCrossNorm, 4)]
    ];

    if (curve.kind === "etg") {
      rows.push(["R80", fmt(curve.stage4.r80, 3) + " kpc"]);
      rows.push(["R90", fmt(curve.stage4.r90, 3) + " kpc"]);
      rows.push(["Sigma80-100", fmt(curve.stage4.sigma80, 4)]);
      rows.push(["logy", fmt(curve.stage4.logy, 4)]);
      rows.push(["Stage4 dR80", fmt(curve.stage4.residualR80, 4)]);
      rows.push(["Stage4 dR90", fmt(curve.stage4.residualR90, 4)]);
      rows.push(["c1 slope law", route.c1 == null ? "--" : fmt(route.c1, 4)]);
      rows.push(["ETG curvature A", route.etgCurvatureA == null ? "--" : fmt(route.etgCurvatureA, 4)]);
    } else {
      rows.push(["f_gas_out", fmt(curve.fGasOut, 4)]);
      rows.push(["L_eff", fmt(curve.leff, 4) + " kpc"]);
      rows.push(["memory load", fmt(curve.memoryLoad, 4)]);
      rows.push(["RMSE", curve.rmse == null ? "--" : fmt(curve.rmse, 4) + " km/s"]);
      rows.push(["L_gap", route.lGap == null ? "--" : fmt(route.lGap, 4) + " kpc"]);
      rows.push(["g = memory*x", route.gScalar == null ? "--" : fmt(route.gScalar, 4)]);
      rows.push(["Priority L MAE", route.priorityL == null ? "--" : fmt(route.priorityL, 4) + " km/s"]);
      rows.push(["Late-load final", route.lateLoad ? "flagged" : "clear"]);
      rows.push(["LTG curvature A", fmt(route.ltgCurvatureA, 4)]);
    }

    if (frameworkScore) {
      rows.push(["Custom expression", frameworkScore.expression]);
      rows.push(["Custom RMSE", fmt(frameworkScore.rmse, 4) + " km/s"]);
      rows.push(["Baseline RMSE", fmt(frameworkScore.baselineRmse, 4) + " km/s"]);
      rows.push(["Custom delta", fmt(frameworkScore.delta, 4) + " km/s"]);
    }

    return rows;
  }

  function buildDiagnosticSheetHtml() {
    var curve = state.curve;
    var rows = diagnosticRows().map(function (row) {
      return "<tr><th>" + htmlEscape(row[0]) + "</th><td>" + htmlEscape(row[1]) + "</td></tr>";
    }).join("");
    return [
      "<!doctype html>",
      "<html lang=\"en\">",
      "<head>",
      "<meta charset=\"utf-8\">",
      "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">",
      "<title>MTS diagnostic sheet - " + htmlEscape(curve.name) + "</title>",
      "<style>",
      "body{margin:0;background:#f6f7f2;color:#14170d;font-family:Inter,Arial,sans-serif}",
      "main{max-width:980px;margin:0 auto;padding:34px}",
      "header{display:flex;justify-content:space-between;gap:24px;border-bottom:2px solid #14170d;padding-bottom:18px;margin-bottom:24px}",
      "h1{margin:0;font-size:30px;line-height:1}p{margin:6px 0 0;color:#4a5145}",
      ".pill{align-self:flex-start;border:1px solid #14170d;border-radius:6px;padding:8px 10px;font-size:12px;font-weight:800;text-transform:uppercase}",
      "section{margin-top:22px}.grid{display:grid;grid-template-columns:320px 1fr;gap:24px;align-items:start}",
      "table{width:100%;border-collapse:collapse;font-size:13px}th,td{border-bottom:1px solid #c9d0c1;padding:8px;text-align:left;vertical-align:top}th{width:42%;color:#4a5145;font-weight:800}",
      ".plots{display:grid;gap:18px}.plot{border:1px solid #c9d0c1;border-radius:8px;background:white;padding:12px}",
      ".plot h2{margin:0 0 8px;font-size:13px;text-transform:uppercase;letter-spacing:.08em;color:#4a5145}",
      ".plot svg{width:100%;height:auto;display:block}",
      "footer{margin-top:24px;color:#66705f;font-size:12px}",
      "@media print{main{padding:18px}.plot{break-inside:avoid}}",
      "</style>",
      "</head>",
      "<body>",
      "<main>",
      "<header><div><h1>" + htmlEscape(curve.name) + "</h1><p>MTS Galaxy Lab diagnostic sheet</p><p>Generated " + htmlEscape(new Date().toISOString()) + "</p></div><div class=\"pill\">" + htmlEscape(state.route.id) + "</div></header>",
      "<section class=\"grid\"><table><tbody>" + rows + "</tbody></table><div class=\"plots\">",
      "<div class=\"plot\"><h2>Rotation Curve</h2>" + styledSvgMarkup("curvePlot") + "</div>",
      "<div class=\"plot\"><h2>u(r) Gate Profile</h2>" + styledSvgMarkup("uPlot") + "</div>",
      "<div class=\"plot\"><h2>Residual View</h2>" + styledSvgMarkup("residualPlot") + "</div>",
      "</div></section>",
      "<footer>Constants: Gamma0=809.956, Rmax=1.758948, ML_disk=0.5, ML_bulge=0.7, q=0.77 for ROTMOD mode.</footer>",
      "</main>",
      "</body>",
      "</html>"
    ].join("");
  }

  function exportCurrentCsv() {
    if (!state.curve) return;
    downloadText(slugify(state.curve.name) + "-curve.csv", currentCurveCsv(), "text/csv;charset=utf-8");
  }

  function exportFilteredCsv() {
    downloadText("mts-ltg-index-" + slugify(state.ltgBrowser.hunt + "-" + state.ltgBrowser.route) + ".csv", ltgIndexCsv(), "text/csv;charset=utf-8");
  }

  function exportSummaryJson() {
    if (!state.curve) return;
    downloadText(slugify(state.curve.name) + "-summary.json", JSON.stringify(currentDiagnosticsObject(), null, 2), "application/json;charset=utf-8");
  }

  function exportPlotSvg() {
    if (!state.curve) return;
    downloadText(slugify(state.curve.name) + "-rotation-curve.svg", styledSvgMarkup("curvePlot"), "image/svg+xml;charset=utf-8");
  }

  function exportSheetHtml() {
    if (!state.curve) return;
    downloadText(slugify(state.curve.name) + "-diagnostic-sheet.html", buildDiagnosticSheetHtml(), "text/html;charset=utf-8");
  }

  function exportFrameworkCsv() {
    if (!state.framework.batch.length) {
      runFrameworkBatch();
    }
    if (!state.framework.batch.length || state.framework.error) return;
    downloadText("mts-framework-scores-" + slugify(state.framework.expression).slice(0, 32) + ".csv", frameworkScoresCsv(), "text/csv;charset=utf-8");
  }

  function randomizeSynthetic() {
    controls.h.value = fmt(1.2 + seededRandom() * 5.5, 1);
    controls.rOut.value = fmt(14 + seededRandom() * 34, 0);
    controls.diskAmp.value = fmt(70 + seededRandom() * 145, 0);
    controls.gasAmp.value = fmt(18 + seededRandom() * 90, 0);
    controls.bulgeAmp.value = fmt(seededRandom() * 155, 0);
    controls.fGas.value = fmt(0.05 + seededRandom() * 0.55, 2);
    controls.q.value = fmt(0.62 + seededRandom() * 0.28, 2);
    buildSyntheticCurve();
    generateParticles();
  }

  function bindEvents() {
    document.querySelectorAll(".mode-button").forEach(function (button) {
      button.addEventListener("click", function () {
        setMode(button.dataset.mode);
      });
    });

    Object.keys(controls).forEach(function (key) {
      controls[key].addEventListener("input", function () {
        if (state.mode === "synthetic") {
          buildSyntheticCurve();
          if (key !== "speed" && key !== "showMtsOnly") generateParticles();
        }
      });
    });

    $("randomize").addEventListener("click", randomizeSynthetic);

    $("sampleSelect").addEventListener("change", loadSelectedSample);
    $("etgSelect").addEventListener("change", loadSelectedEtg);
    $("galaxySearch").addEventListener("input", function (event) {
      state.ltgBrowser.search = event.target.value;
      updateLtgBrowser();
    });
    $("routeFilter").addEventListener("change", function (event) {
      state.ltgBrowser.route = event.target.value;
      updateLtgBrowser();
    });
    $("sortSelect").addEventListener("change", function (event) {
      state.ltgBrowser.sort = event.target.value;
      updateLtgBrowser();
    });
    document.querySelectorAll(".hunt-button").forEach(function (button) {
      button.addEventListener("click", function () {
        state.ltgBrowser.hunt = button.dataset.hunt;
        document.querySelectorAll(".hunt-button").forEach(function (other) {
          other.classList.toggle("active", other === button);
        });
        updateLtgBrowser();
      });
    });

    $("loadPasted").addEventListener("click", function () {
      try {
        loadObservedCurve(parseRotmod($("pasteInput").value, "Pasted ROTMOD"));
      } catch (error) {
        window.alert(error.message);
      }
    });

    $("fileInput").addEventListener("change", function (event) {
      var file = event.target.files && event.target.files[0];
      if (!file) return;
      var reader = new FileReader();
      reader.onload = function () {
        try {
          loadObservedCurve(parseRotmod(String(reader.result), file.name));
          $("pasteInput").value = String(reader.result);
        } catch (error) {
          window.alert(error.message);
        }
      };
      reader.readAsText(file);
    });

    $("exportCurrentCsv").addEventListener("click", exportCurrentCsv);
    $("exportFilteredCsv").addEventListener("click", exportFilteredCsv);
    $("exportSummaryJson").addEventListener("click", exportSummaryJson);
    $("exportPlotSvg").addEventListener("click", exportPlotSvg);
    $("exportSheetHtml").addEventListener("click", exportSheetHtml);
    $("applyFramework").addEventListener("click", applyFrameworkExpression);
    $("runFrameworkBatch").addEventListener("click", runFrameworkBatch);
    $("exportFrameworkCsv").addEventListener("click", exportFrameworkCsv);
    $("frameworkPreset").addEventListener("change", function (event) {
      var preset = FRAMEWORK_PRESETS[event.target.value] || FRAMEWORK_PRESETS.mts;
      $("frameworkFormula").value = preset;
      applyFrameworkExpression();
    });

    window.addEventListener("resize", resizeCanvas);
  }

  function init() {
    cacheControls();
    setupSamples();
    setupEtgSamples();
    $("frameworkFormula").value = state.framework.expression;
    state.framework.compiled = compileFrameworkExpression(state.framework.expression);
    bindEvents();
    resizeCanvas();
    buildSyntheticCurve();
    generateParticles();
    if ((window.MTS_SAMPLES || []).length) {
      $("sampleSelect").value = "0";
    }
    if ((window.MTS_ETG_SAMPLES || []).length) {
      $("etgSelect").value = "0";
    }
    var queryMode = new URLSearchParams(window.location.search).get("mode");
    if (queryMode === "observed" || queryMode === "etg") {
      setMode(queryMode);
    }
    updateLtgBrowser();
    requestAnimationFrame(drawGalaxy);
  }

  init();
}());
