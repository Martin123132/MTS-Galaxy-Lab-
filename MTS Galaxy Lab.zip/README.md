# MTS Galaxy Lab

Zero-install browser prototype for exploring the Motion-Timespace galaxy law as an interactive transport-response simulator.

## Open

Open this file in a browser:

```text
C:\Users\ollet\OneDrive\Documents\mts-galaxy-lab\index.html
```

The app is static HTML/CSS/JavaScript. It does not need Node, Python, npm, or a local server.

## Modes

- Synthetic: builds a toy disk from slider-controlled disk, gas, bulge, and memory-load parameters.
- LTG: loads all 175 bundled SPARC samples generated from `Rotmod_LTG (4).zip`, or accepts a pasted/imported ROTMOD `.dat` file.
- ETG: loads all 16 bundled ATLAS3D ETGs from `Rotmod_ETG.zip`, including high-resolution disk and bulge components.

## Locked Constants

```text
Gamma0 = 809.956
Rmax = 1.758948
ML_disk = 0.5
ML_bulge = 0.7
q = 0.77 for ROTMOD mode
```

## Formulae Implemented

```text
V_bar^2 = V_gas^2 + 0.5 V_disk^2 + 0.7 V_bulge^2

S_mem = (0.9 / pi) * (r_out / h)
memory_load = (1 - f_gas_out) * (r_out / h)
L_eff = 1.8 h * (1 + S_mem * (1 - exp(-memory_load / S_mem)))

V_model^2(r) = V_bar^2(r) + Gamma0 * L_eff * (1 - exp(-(r / L_eff)^q))

u(r) = (V_obs^2 - 0.5 V_disk^2 - 0.7 V_bulge^2) / (Gamma0 * r * Rmax)
```

For synthetic mode, `V_obs` is the generated MTS model. For ROTMOD mode, `V_obs` is the observed SPARC value.

## v17 / Paper v15 Diagnostics

LTG single-crossing diagnostics:

```text
L_gap = L_sat - L_exact
g = memory_load * x_cross
Priority L MAE ~= -10.4 + 8.6*g + 10.5*L_gap
late-load final flag = u_out > 0.64 AND h/r_out > 0.095
LTG curvature A ~= 2.210 - 2.028*u_0.75
```

ETG diagnostics:

```text
Stage-4 R80 row: logy ~= 4.313 + 0.808*log(Sigma80-100) + 1.732*log(r_out/R80)
Stage-4 R90 row: logy ~= 4.7556 + 0.8348*log(Sigma80-100) + 1.7153*log(r_out/R90)
c1 slope law = -(1-u_out)/(1-x_cross)
ETG curvature A ~= -0.015 + 1.029*(1-x_cross)
```

The app uses locked v17 table values for ETG `h`, `R90`, `Sigma80-100`, and `logy`; `R80` is computed live from the bundled high-res disk profile because the state transfer notes that it is quadrature-sensitive.

## Regenerate Bundled Samples

If the LTG archive moves, pass a new path:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\export-samples.ps1 -ZipPath "C:\path\to\Rotmod_LTG (4).zip"
```

The SPARC Browser indexes all 175 LTGs and supports:

```text
search by galaxy name
filter by route class
sort by RMSE, u_out, Priority L MAE, x_cross, or name
quick hunts: Late-load, CDC, Single, Infeasible, Worst, Best
route summary chips: low, upward, single, infeasible, CDC-low, late flag
```

## Evidence Pack

The left rail now includes export tools:

```text
Current CSV: active curve point table with r, velocities, u(r), and residual
LTG Index CSV: current filtered/sorted SPARC browser diagnostics
Summary JSON: active galaxy constants, curve state, route state, and browser filters
Plot SVG: standalone rotation-curve SVG with embedded plot styling
Diagnostic Sheet: standalone HTML sheet with metrics, rotation curve, u(r), and residual view
```

The right rail also includes a residual plot:

```text
Synthetic mode: MTS support share
LTG mode: V_model - V_observed in km/s
ETG mode: Stage-4 log residual markers
```

## Framework Test Rig

The app can test alternate frameworks without overwriting the locked MTS baseline. Enter a support-law expression for `v2` in `(km/s)^2`, run it on the active galaxy, then batch-score it against all 175 LTGs.

Bundled presets:

```text
MTS baseline
Baryon only
Soft radial support
Outer gate support
Observed residual check
```

Allowed formula variables:

```text
r, x, h, rOut, fGas, fGasOut, leff, memory, q
gamma0, rMax, mlDisk, mlBulge
vGas, vDisk, vBulge, vBar, vObs, uObs
pi, e
```

Allowed math functions:

```text
abs, sqrt, pow, exp, log, log10, min, max
sin, cos, tan, tanh, atan, atan2, floor, ceil, round
```

The formula editor accepts restricted math expressions, not general JavaScript. The current custom curve is drawn as a white dashed overlay, the residual plot switches to custom residuals, and `Export Framework Scores` writes the latest 175-LTG batch table as CSV.

## Regenerate ETG Samples

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\export-etg-samples.ps1 -ZipPath "C:\path\to\Rotmod_ETG.zip"
```

## Verification

Rendered locally with Microsoft Edge headless:

```text
qa-desktop.png
qa-observed.png
qa-observed-v2.png
qa-etg-v2.png
qa-mobile.png
qa-evidence-observed.png
qa-evidence-etg.png
qa-evidence-mobile.png
qa-framework-observed-v2.png
qa-framework-mobile.png
qa-framework-batch-v3.png
```

The Edge console emitted browser-internal task-manager/sync warnings, but the screenshots and DOM showed the app loaded, plotted data, and computed the ROTMOD overlays. A CDP click test also ran the Framework Test Rig over all 175 LTGs with the baryon-only preset and confirmed the batch table updated.
